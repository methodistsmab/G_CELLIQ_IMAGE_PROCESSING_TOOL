%function nextfig()
%step to next figure

function nextfig()

figure(gcf+1);
