function flush
drawnow
