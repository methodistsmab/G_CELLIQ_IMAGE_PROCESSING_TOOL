function linewidth(l,w);

set(l,'LineWidth',w);
