1) Demo code is GA_demo.m;
2) Main code is varselect_GA_open.m;
3) The cost function is defined in varselect_gafit.m, which can be replace by self defined one.



Updated by Jun Wang (jwang@bwh.harvard.edu)
Feb. 5, 2006


input one raw image .... get all the cells .... extract each cell's features(201)
.... get each cell's type number.

first: get the cells,

second: get the features,

third: get the cell's type number.