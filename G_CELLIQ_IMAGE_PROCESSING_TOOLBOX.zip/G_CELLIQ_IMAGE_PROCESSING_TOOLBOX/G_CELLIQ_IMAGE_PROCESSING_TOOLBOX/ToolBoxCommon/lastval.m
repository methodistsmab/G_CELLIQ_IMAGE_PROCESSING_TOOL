%function v=lastval(list)
% last value in list

function v=lastval(list)
v=list(length(list));
